# Long-Term Memory

## Preferences

### Search
- **Default search tool:** searxng skill (privacy-respecting local metasearch)
- When any web search is needed, prioritize the searxng skill over web_search (Brave API)
- SearXNG instance: configured via `SEARXNG_URL` env var (default: `http://localhost:8080`)

### 🤖 Telegram Bot 配置（2026-03-19 16:15 更新）

**当前使用的 Bot**:
- **Bot Token**: `8784296779:AAFYFtE69lyvOFAAuRazuNbKZxG5mUtIQHk`
- **Chat ID**: `1233887750`
- **用途**: V3 系统告警通知、健康报告

**历史 Bot**:
- 旧 Bot: `8611422539:AAHK2M7Mt-wfQmf5zz1aZUjnCRpkZT1wmVI` (@rytongzhi_bot)
- 更换时间：2026-03-19 16:15
- 更换原因：用户指定更换

**配置位置**:
- `scripts/strategy_guardian_v2.sh` - 策略守护告警
- `scripts/health_check.sh` - 健康检查报告

---

### 💡 工作风格（2026-03-07 11:04）
**主动建议原则：**
- 对底层优化任务（Python 版本、系统架构、性能瓶颈等），要**主动给出建议**
- 不要等用户问才说，要提前分析并推荐最优方案
- 建议需包含：现状分析、多个方案对比、预期收益、执行步骤
- 适用场景：技术升级、架构优化、性能提升、自动化改进

**示例：**
- ❌ 被动："Python 3.6 有多进程问题，怎么办？"
- ✅ 主动："检测到 Python 3.6 限制了多进程性能，建议升级到 3.8+，预计速度提升 3-4 倍。方案 A... 方案 B..."

---

### 🔍 硬件分析前置原则（2026-03-07 11:08）
**给出任何优化建议前，必须先分析服务器硬件条件：**

1. **CPU** - 核心数、型号、当前负载
2. **内存** - 总量、可用量、swap 情况
3. **磁盘** - 容量、剩余空间、IO 性能
4. **网络** - 带宽、延迟（如需下载/上传）
5. **系统** - OS 版本、内核、包管理器

**可行性判断标准：**
- ✅ 推荐：资源充足（>50% 余量），风险低
- ⚠️ 谨慎：资源紧张（20-50% 余量），需监控
- ❌ 不可行：资源不足（<20% 余量），需扩容

**示例流程：**
```
1. 执行硬件检查命令（free -h, df -h, nproc, etc.）
2. 分析当前资源使用情况
3. 评估方案资源需求
4. 判断可行性并给出建议
```

## 👑 大王核心指令 (P0 最高优先级)

**时间：** 2026-03-03 18:53

**秒回指令：**
- 收到大王消息 → 立即回复"收到！"（<3 秒）

---

## 📋 v3.1 策略类编写规范（P0 最高优先级）

**创建时间**: 2026-03-14 21:11

**核心原则**:
1. 单一职责 - 每个策略文件只负责一个策略逻辑
2. 配置分离 - 策略参数在 `__init__` 中配置
3. 循环运行 - `run()` 方法必须支持循环调用
4. 状态持久化 - 每根 K 线后保存状态
5. 异常处理 - 所有外部调用必须 try-except
6. 日志记录 - 关键操作必须记录日志

**标准结构**:
```python
class StrategyName:
    def __init__(self, symbol, leverage, amount):
        self.symbol = symbol
        self.leverage = leverage
        self.amount = amount
        self.position = None  # 必须
        self.entry_price = 0  # 必须
        self.last_rsi = 0     # 必须
        self.is_running = False  # 必须
    
    def run(self, interval: int = 60):
        self.is_running = True  # 必须先设置为 True
        while self.is_running:
            try:
                # 获取数据 → 计算指标 → 检查信号 → 执行交易
                time.sleep(interval)
            except KeyboardInterrupt:
                self.is_running = False
                break
            except Exception as e:
                time.sleep(10)
```

**关键检查点**:
- ✅ `is_running` 属性必须初始化
- ✅ `run()` 方法必须有 `interval` 参数
- ✅ `run()` 开始必须设置 `self.is_running = True`
- ✅ while 循环必须有 try-except
- ✅ 必须有 KeyboardInterrupt 处理
- ✅ 所有 API 调用必须 try-except

**模板文件**: `strategies/strategy_template.py`
**完整文档**: `STRATEGY_TEMPLATE_AND_GUIDE.md`
- 单独发送，不与后续消息合并
- 不调 API，纯自动回复
- 优先处理，高于所有其他任务

**适用场景：** 所有来自大王的消息

## 👤 用户信息

### 大王
- **称呼：** 大王
- **钉钉：** 一路向前 666
- **手机：** 15305719380
- **时区：** Asia/Shanghai

## Notes

- Memory file created: 2026-02-28
- User prefers privacy-focused search tools
- 资料恢复完成：2026-03-04（从 /home/admin/longxiawang 恢复）
- 记忆二次恢复：2026-03-05 01:36（从聊天导出文件恢复）
- **HEARTBEAT.md 归档：** 2026-03-12 01:31（保留最近 10 条，历史归档至 HEARTBEAT_ARCHIVE_20260309-0312_*.md）

## 📊 量化策略核心数据（截至 2026-03-04）

### 最优策略
- **策略名：** breakout (突破策略)
- **8 年回测：** +13.64% 总收益
- **胜率：** 45.44%
- **最大回撤：** 6.83%
- **最佳币种：** AVAXUSDT (+20.18%)

### 100% 年化计划
- **目标：** 100% 年化收益
- **仓位：** 20% → 60%（激进）
- **年交易次数：** 2-3 次 → 12-15 次
- **盈亏比：** 1.9 → 3:1
- **策略调整：** 提高交易频率，优化出场

### 关键文件
- `/home/admin/.openclaw/workspace/quant/backtest/strategy_comparison_table.md` - 策略对比表
- `/home/admin/.openclaw/workspace/quant/100pct_annual_plan.md` - 100% 年化计划
- `/home/admin/.openclaw/workspace/quant/10_strategies_backtest.md` - 10 策略回测报告

## ⚠️ 安全教训

- **2026-03-04 事故：** 搬文件到 `/home/admin` 导致 OpenClaw 消失（LLM timeout）
- **原则：** 不动 `.openclaw` 系统目录，只在 workspace 内操作
- **备份位置：** `/home/admin/longxiawang/longxiawang/` - 旧工作目录完整备份

---

## 👑 大王核心指令（2026-03-09 19:34 新增）

### 工作风格：先记录，后执行

**规则：**
- 收到用户消息 → **先记录，不执行**
- 等待用户明确确认 → **再开始执行**
- 禁止擅自行动

**适用场景：**
- 所有任务执行请求
- 所有修复操作
- 所有代码修改

**例外：**
- P0 紧急修复（用户已明确授权）
- 心跳检查（自动执行）

**违反后果：**
- 用户需要多次确认
- 浪费时间
- 可能执行错误任务

---

## 🔌 V3 策略热插拔系统（2026-03-19 16:05 新增）

**核心机制：**
1. **策略文件管理** - `.active_strategies` 文件控制哪些策略运行
2. **自动加载器** - `auto_strategy_loader.py` 每 60 秒检查变化
3. **Supervisor 自动更新** - 自动增删策略进程，无需重启
4. **Guardian 动态监控** - 自动监控所有激活的策略

**添加新策略：**
```bash
# 1. 编辑激活列表
vi /root/.openclaw/workspace/quant/v3-architecture/.active_strategies

# 2. 添加策略名（一行一个）
new_strategy_name

# 3. 等待 60 秒自动生效
# 或手动触发：supervisorctl reread && supervisorctl update
```

**删除策略：**
```bash
# 从 .active_strategies 删除对应行
# 等待 60 秒自动停止
```

**关键文件：**
- `.active_strategies` - 激活策略列表
- `scripts/auto_strategy_loader.py` - 自动加载器
- `supervisor/auto_strategies.conf` - 自动生成的 Supervisor 配置
- `logs/auto_loader.log` - 加载器日志

**记忆原则：**
- ✅ 热插拔机制必须永久记录
- ✅ 用户偏好策略必须记录
- ✅ 历史故障必须记录避免重犯
- ✅ 配置变更必须同步更新 MEMORY.md

---

## 🎯 V3 系统完善计划（2026-03-19 16:20 新增）

**完善逻辑框架：**
```
发现问题 → 修复问题 → 反思根本原因 → 系统性完善 → 建立验证机制 → 文档化 → 更新记忆
```

**核心原则：**
1. 主动思考 > 被动响应
2. 系统完善 > 单点修复
3. 预防优先 > 事后修复
4. 永久记忆 > 临时方案
5. 验证闭环 > 做了就算

**分阶段计划：**
- **阶段 1（本周）**: 基础保障（配置备份、性能监控、自动回滚、日志轮转）
- **阶段 2（下周）**: 数据持久化（策略状态、交易记录、监控数据）
- **阶段 3（下下周）**: 用户体验（Web 管理界面、故障知识库）
- **阶段 4（长期）**: 智能化（AI 异常预测、自动策略优化）

**完整计划**: `/root/.openclaw/workspace/quant/v3-architecture/V3_SYSTEM_PERFECTION_PLAN.md`

---

## 🔧 维修流程规范（永久执行）（2026-03-16 08:20 新增）

### 🎯 标准流程

**1. 查阅资料 → 2. 全面检查 → 3. 实施修复 → 4. 验证测试**

---

### 📚 第 1 步：查阅资料 (必须)

**查阅内容:**
1. ✅ 官方文档 - 币安 API 手册、错误代码
2. ✅ 历史报告 - 之前的维修记录、修复报告
3. ✅ 项目文档 - API 参考、设计规范
4. ✅ 日志文件 - 错误日志、监控日志

**目的:**
- 了解问题的历史背景
- 避免重复踩坑
- 找到根本原因而非表面症状

---

### 🔍 第 2 步：全面检查 (必须)

**检查内容:**
1. ✅ 代码层面 - 相关逻辑、错误处理
2. ✅ 数据层面 - 实际持仓 vs 本地状态
3. ✅ API 层面 - 端点是否正确、精度处理
4. ✅ 流程层面 - 是否有验证、兜底机制

**目的:**
- 找到所有相关问题点
- 理解问题的系统性原因
- 制定完整的修复方案

---

### 🔧 第 3 步：实施修复 (必须)

**修复原则:**
1. ✅ 治本不治标 - 解决根本原因
2. ✅ 系统性方案 - 添加机制而非临时补丁
3. ✅ 完整流程 - 成功路径 + 错误处理 + 兜底
4. ✅ 验证测试 - 修复后必须验证

**修复内容:**
- 状态同步机制
- 硬限制约束
- 完整错误处理
- 验证和兜底

---

### ✅ 永久执行

**以后所有维修:**
1. 必须先查阅资料 (官方文档 + 历史报告)
2. 必须全面检查 (代码 + 数据 + API + 流程)
3. 必须系统性修复 (机制而非补丁)
4. 必须验证测试 (修复后验证)

**禁止:**
- ❌ 不查资料直接修复
- ❌ 只修复表面症状
- ❌ 添加临时补丁
- ❌ 不验证就认为完成

---

**参考案例:** 2026-03-10 止损单修复（启动同步机制 + Algo Order API + 精度处理 + 创建后验证）

---

## 📋 标准操作流程 SOP（P0 最高优先级）（2026-03-18 钉钉转发）

**来源**: 大王通过钉钉转发  
**文档位置**: `/root/.openclaw/workspace/SOP.md`  
**状态**: ✅ 已生效

### 核心流程

```
1. 查阅资料 → 2. 全面检查 → 3. 实施修复 → 4. 验证测试
```

### 服务管理

**启动顺序:**
1. OpenClaw Gateway (systemd user)
2. Supervisor 守护进程
3. quant-multi-strategy (Supervisor)
4. quant-unified-monitor (Supervisor)
5. quant-web-dashboard (Supervisor)
6. 监控脚本 (v23_realtime/enhanced/deep)

**停止顺序:**
1. 监控脚本
2. Supervisor 管理的服务
3. Supervisor 守护进程
4. OpenClaw Gateway

### 故障排查三步法

**第 1 步：状态检查**
```bash
supervisorctl status
systemctl --user status openclaw-gateway
ps aux | grep -E "openclaw|multi_strategy|unified_monitor"
netstat -tlnp | grep -E "18789|8000"
```

**第 2 步：日志检查**
```bash
tail -100 /tmp/openclaw/openclaw-*.log
tail -100 /root/.openclaw/supervisor/logs/*.log
tail -100 /root/.openclaw/workspace/quant/v3-architecture/logs/*.log
```

**第 3 步：API 检查**
```bash
curl -s http://localhost:8000/api/health
curl -s http://localhost:8000/api/binance/account
curl -s http://localhost:8000/api/strategy/active
```

### 维修记录格式

必须包含：
- 日期时间
- 问题描述
- 根本原因
- 时间线（表格）
- 修复步骤
- 验证结果
- 预防措施

### 日常巡检

**每日:**
- [ ] Web Dashboard 可访问
- [ ] 策略运行正常
- [ ] 监控系统正常
- [ ] 日志无 ERROR
- [ ] 币安 API 连接正常

**每周:**
- [ ] 系统资源使用（CPU/内存/磁盘）
- [ ] 日志文件大小
- [ ] 备份文件完整性
- [ ] 策略性能回顾

### 紧急响应级别

| 级别 | 响应时间 | 流程 |
|------|----------|------|
| **P0** | < 3 分钟 | 立即响应 → 备用系统 → 通知大王 → 根因分析 → 修复验证 → 报告 |
| **P1** | < 10 分钟 | 响应 → 排查 → 修复 → 验证 → 记录 |
| **P2** | 工作时间 | 记录 → 分析 → 方案 → 实施 → 文档 |

---

## 📦 Skills 安装规范（P0 最高优先级）（2026-03-18 教学视频整理）

### 安装原则

**核心原则**:
1. **不要贪多** - 装太多会让 Agent 错乱
2. **避免冲突** - 有些技能可能会相抵触
3. **注意安全** - 很多 Skills 被塞了恶意提示码
4. **先检查后安装** - 使用 Skills Veter 扫描

**安装来源**:
- ✅ ClawHub (https://clawhub.com) - 官方市集
- ⚠️ GitHub - 需仔细检查
- ❌ 不明来源 - 禁止安装

---

### 必装 Skills 清单（按重要性排序）

#### 🔴 第一梯队：必须安装

**1. Skills Veter (clawvet)** 🛡️ (P0 - ✅ 已安装)
- 功能：安全扫描，检测恶意提示码
- 用途：安装任何 Skills 前先扫描
- 状态：✅ 已安装并构建完成
- 位置：`/root/.openclaw/workspace/skills/skills-veter/`
- 快捷命令：`/root/.openclaw/workspace/skills/clawvet-scan.sh <skill 路径>`
- 风险评分：6.78/100 (Grade: A) ✅ 安全

**2. self-improving-agent** 🧠 (P0)
- 功能：记录错误/成功经验，用户偏好
- 用途：越用越聪明，避免重复错误
- 状态：✅ 已存在

#### 🟡 第二梯队：强烈推荐

**3. Tavily Search (tavily-web-search-for-openclaw)** 🔍 (P1 - ✅ 已安装)
- 功能：搜索增强，返回 AI 可直接处理的结果
- 用途：市场研究、数据查证
- 状态：✅ 已安装并通过 clawvet 扫描 (Risk: 0/100, Grade: A)
- 位置：`/root/.openclaw/workspace/skills/tavily-web-search-for-openclaw/`
- API Key: 需要 Tavily API Key（免费额度：1000 次/月）
- 获取 API Key: https://app.tavily.com/

**4. Summarize** 📝 (P1 - ✅ 已安装)
- 功能：整理网页、PDF、图片、音频、视频
- 用途：长内容压缩
- 状态：✅ 已安装并通过 clawvet 扫描 (Risk: 21.6/100, Grade: B)
- 位置：`/root/.openclaw/workspace/skills/summarize/`
- API Key: 需要 OpenAI 或 Anthropic API Key（可选）

**5. Find Skills** 🔎 (P1)
- 功能：帮你找 Skills 的 Skills
- 状态：✅ 已存在

**6. skill-creator** ✍️ (P1)
- 功能：自己编写 Skills
- 状态：✅ 已存在

#### 🟢 第三梯队：按需安装

**7. Using Superpowers** 🦸 (P2 - ✅ 已安装)
- 功能：让龙虾先查 Skills 再工作
- 状态：✅ 已安装并通过 clawvet 扫描 (Risk: 0/100, Grade: A)
- 位置：`/root/.openclaw/workspace/skills/using-superpowers/`

**8. Agent Browser** 🌐 (P2)
- 功能：浏览器自动化
- 状态：✅ 已存在

**9. Playwright** 🎭 (P2)
- 功能：浏览器自动化
- 状态：待安装

**10. Gog (Google)** 📧 (P2)
- 功能：Gmail/日历/Drive 集成
- 状态：按需安装

---

### 安装顺序

**阶段 1：安全基础**
```bash
1. Skills Veter（安全扫描）
2. self-improving-agent（已存在）
```

**阶段 2：核心能力**
```bash
3. Tavily Search（搜索增强）
4. Summarize（内容总结）
5. Find Skills（已存在）
6. skill-creator（已存在）
```

**阶段 3：能力增强**
```bash
7. Using Superpowers
8. Agent Browser（已存在）
9. Playwright
10. Gog（按需）
```

---

### 安全检查流程

```bash
# ❌ 错误做法
直接安装 Skills

# ✅ 正确做法
1. 让龙虾读取 Skills 内容
2. 使用 Skills Veter 扫描
3. 检查红旗提示
4. 检查恶意注入
5. 让龙虾重写有问题的部分
```

---

### 已恢复 Skills

| Skills | 状态 | 位置 |
|--------|------|------|
| self-improving-agent | ✅ | `/root/.openclaw/workspace/skills/` |
| find-skills | ✅ | `/root/.openclaw/workspace/skills/` |
| skill-creator | ✅ | `/root/.openclaw/workspace/skills/` |
| agent-browser | ✅ | `/root/.openclaw/workspace/skills/` |
| searxng | ✅ | `/root/.openclaw/workspace/skills/` |
| binance-futures-trading | ✅ | `/root/.openclaw/workspace/skills/` |
| binance-pro | ✅ | `/root/.openclaw/workspace/skills/` |
| binance-stop-loss-manager | ✅ | `/root/.openclaw/workspace/skills/` |

---

### 参考文档

- **完整指南**: `/root/.openclaw/workspace/SKILLS_INSTALLATION_GUIDE.md`
- **ClawHub**: https://clawhub.com
- **OpenClaw 文档**: https://docs.openclaw.ai

---


---

## 🔧 2026-03-18 23:50 重要状态记录

### V3 系统当前状态

**策略进程**:
- ETHUSDT: running, RSI=53.00, signals=0/0
- LINKUSDT: running, RSI=63.64, signals=0/0
- AVAXUSDT: running, RSI=43.82, signals=2/2

**持仓**:
- ETHUSDT: 0.017 @ 2259.98, 杠杆=3, 盈亏=-1.33 USDT
- AVAXUSDT: 49.0 @ 9.54, 杠杆=8, 盈亏=-0.08 USDT

**止损单**:
- ETHUSDT: 0.017 @ 2146.99 (-5%) ✅ 已设置
- AVAXUSDT: 49.0 @ 9.07 (-5%) ✅ 已设置

**已修复问题**:
1. ✅ 策略代码修复 - 开单后立即设置止损
2. ✅ 手动设置现有持仓止损
3. ✅ 停止误报源 (enhanced_monitor.py)

**监控脚本**:
- smart_monitor_v2.sh - 每 10 分钟检查策略共性
- v3_full_monitor.sh - 每 10 分钟检查完整流程

**重要教训**:
- 开单后必须调用 create_stop_loss()
- 杠杆配置要与策略一致
- 监控要抓住共性，不要报假警

**下次检查**: 每 10 分钟自动检查

---

## 🔧 2026-03-19 00:20 重要记忆更新

### 记忆管理规则（必须遵守）

**规则 1: 重复提醒检查**
- 如果用户重复提醒同一件事
- 立刻检查 MEMORY.md 是否已记录
- 没记录就立刻追加
- 已记录就检查为什么没执行

**规则 2: 会话开始主动回忆**
- 每次会话开始，先用 memory_search 搜索过去 3 天相关内容
- 主动回忆当前状态和待办事项
- 不要等用户提醒才想起来

**规则 3: 状态持久化**
- 重要状态必须记录到 MEMORY.md
- 当前状态记录到 monitor_state/current_status.json
- 详细记录到监控日志

### 当前 V3 系统状态（已记录）

**策略状态**:
- ETHUSDT: running, signals=0/0
- LINKUSDT: running, signals=0/0
- AVAXUSDT: running, signals=1/1

**持仓**:
- ETHUSDT: 0.017 @ 2259.98, 杠杆=3, 止损=2146.99 ✅
- AVAXUSDT: 79.0 @ 9.54, 杠杆=8, 止损=9.07 ✅

**监控脚本**:
- v3_full_monitor_v2.sh - 每 10 分钟检查
- 监控内容：策略运行/信号执行/止损设置

**已修复问题**:
1. ✅ 策略代码修复 - 开单后立即设置止损
2. ✅ 手动设置现有持仓止损
3. ✅ 停止旧监控（enhanced/deep/service_monitor）
4. ✅ 禁用旧监控配置（.bak）

**监控原则**:
- ✅ 只监控共性（进程/信号/止损）
- ❌ 不监控个性（RSI/指标/策略逻辑）

**下次检查**: 每 10 分钟自动检查
